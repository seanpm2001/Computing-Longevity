
***

# The Computing-longevity project

![UNIVERSEICON2.png This image failed to load. It may be due to the file not being reached, or a general error. Reload the page to fix a possible general error.](/UNIVERSEICON2.png)

# By:

<!-- ![{Developer name} This image failed to load. It may be due to the file not being reached, or a general error. Reload the page to fix a possible general error.](/Image2.svg) !-->

## [Seanpm2001](https://github.com/seanpm2001/) / [Computing-longevity](https://github.com/Computing-longevity), Et; Al.
  
### Top

# `README.md`

***

## Read this article in a different language

_🌐 List of languages_

**Sorted by:** `A-Z`

[Sorting options unavailable](https://github.com/Computing-longevity/Computing-longevity.github.io/)

( [af Afrikaans](/.github/README_AF.md) Afrikaans | [sq Shqiptare](/.github/README_SQ.md) Albanian | [am አማርኛ](/.github/README_AM.md) Amharic | [ar عربى](/.github/README_AR.md) Arabic | [hy հայերեն](/.github/README_HY.md) Armenian | [az Azərbaycan dili](/.github/README_AZ.md) Azerbaijani | [eu Euskara](/.github/README_EU.md) Basque | [be Беларуская](/.github/README_BE.md) Belarusian | [bn বাংলা](/.github/README_BN.md) Bengali | [bs Bosanski](/.github/README_BS.md) Bosnian | [bg български](/.github/README_BG.md) Bulgarian | [ca Català](/.github/README_CA.md) Catalan | [ceb Sugbuanon](/.github/README_CEB.md) Cebuano | [ny Chichewa](/.github/README_NY.md) Chichewa | [zh-CN 简体中文](/.github/README_ZH-CN.md) Chinese (Simplified) | [zh-t 中國傳統的）](/.github/README_ZH-T.md) Chinese (Traditional) | [co Corsu](/.github/README_CO.md) Corsican | [hr Hrvatski](/.github/README_HR.md) Croatian | [cs čeština](/.github/README_CS.md) Czech | [da dansk](README_DA.md) Danish | [nl Nederlands](/.github/README_NL.md) Dutch | [**en-us English**](/.github/README.md) English |  [EO Esperanto](/.github/README_EO.md) Esperanto | [et Eestlane](/.github/README_ET.md) Estonian | [tl Pilipino](/.github/README_TL.md) Filipino | [fi Suomalainen](/.github/README_FI.md) Finnish |  [fr français](/.github/README_FR.md) French | [fy Frysk](/.github/README_FY.md) Frisian | [gl Galego](/.github/README_GL.md) Galician | [ka ქართველი](/.github/README_KA) Georgian | [de Deutsch](/.github/README_DE.md) German | [el Ελληνικά](/.github/README_EL.md) Greek | [gu ગુજરાતી](/.github/README_GU.md) Gujarati | [ht Kreyòl ayisyen](/.github/README_HT.md) Haitian Creole | [ha Hausa](/.github/README_HA.md) Hausa | [haw Ōlelo Hawaiʻi](/.github/README_HAW.md) Hawaiian | [he עִברִית](/.github/README_HE.md) Hebrew | [hi हिन्दी](/.github/README_HI.md) Hindi | [hmn Hmong](/.github/README_HMN.md) Hmong | [hu Magyar](/.github/README_HU.md) Hungarian | [is Íslenska](/.github/README_IS.md) Icelandic | [ig Igbo](/.github/README_IG.md) Igbo | [id bahasa Indonesia](/.github/README_ID.md) Icelandic | [ga Gaeilge](/.github/README_GA.md) Irish | [it Italiana/Italiano](/.github/README_IT.md) | [ja 日本語](/.github/README_JA.md) Japanese | [jw Wong jawa](/.github/README_JW.md) Javanese | [kn ಕನ್ನಡ](/.github/README_KN.md) Kannada | [kk Қазақ](/.github/README_KK.md) Kazakh | [km ខ្មែរ](/.github/README_KM.md) Khmer | [rw Kinyarwanda](/.github/README_RW.md) Kinyarwanda | [ko-south 韓國語](/.github/README_KO_SOUTH.md) Korean (South) | [ko-north 문화어](README_KO_NORTH.md) Korean (North) (NOT YET TRANSLATED) | [ku Kurdî](/.github/README_KU.md) Kurdish (Kurmanji) | [ky Кыргызча](/.github/README_KY.md) Kyrgyz | [lo ລາວ](/.github/README_LO.md) Lao | [la Latine](/.github/README_LA.md) Latin | [lt Lietuvis](/.github/README_LT.md) Lithuanian | [lb Lëtzebuergesch](/.github/README_LB.md) Luxembourgish | [mk Македонски](/.github/README_MK.md) Macedonian | [mg Malagasy](/.github/README_MG.md) Malagasy | [ms Bahasa Melayu](/.github/README_MS.md) Malay | [ml മലയാളം](/.github/README_ML.md) Malayalam | [mt Malti](/.github/README_MT.md) Maltese | [mi Maori](/.github/README_MI.md) Maori | [mr मराठी](/.github/README_MR.md) Marathi | [mn Монгол](/.github/README_MN.md) Mongolian | [my မြန်မာ](/.github/README_MY.md) Myanmar (Burmese) | [ne नेपाली](/.github/README_NE.md) Nepali | [no norsk](/.github/README_NO.md) Norwegian | [or ଓଡିଆ (ଓଡିଆ)](/.github/README_OR.md) Odia (Oriya) | [ps پښتو](/.github/README_PS.md) Pashto | [fa فارسی](/.github/README_FA.md) |Persian  [pl polski](/.github/README_PL.md) Polish | [pt português](/.github/README_PT.md) Portuguese | [pa ਪੰਜਾਬੀ](/.github/README_PA.md) Punjabi | No languages available that start with the letter Q | [ro Română](/.github/README_RO.md) Romanian | [ru русский](/.github/README_RU.md) Russian | [sm Faasamoa](/.github/README_SM.md) Samoan | [gd Gàidhlig na h-Alba](/.github/README_GD.md) Scots Gaelic | [sr Српски](/.github/README_SR.md) Serbian | [st Sesotho](/.github/README_ST.md) Sesotho | [sn Shona](/.github/README_SN.md) Shona | [sd سنڌي](/.github/README_SD.md) Sindhi | [si සිංහල](/.github/README_SI.md) Sinhala | [sk Slovák](/.github/README_SK.md) Slovak | [sl Slovenščina](/.github/README_SL.md) Slovenian | [so Soomaali](/.github/README_SO.md) Somali | [[es en español](/.github/README_ES.md) Spanish | [su Sundanis](/.github/README_SU.md) Sundanese | [sw Kiswahili](/.github/README_SW.md) Swahili | [sv Svenska](/.github/README_SV.md) Swedish | [tg Тоҷикӣ](/.github/README_TG.md) Tajik | [ta தமிழ்](/.github/README_TA.md) Tamil | [tt Татар](/.github/README_TT.md) Tatar | [te తెలుగు](/.github/README_TE.md) Telugu | [th ไทย](/.github/README_TH.md) Thai | [tr Türk](/.github/README_TR.md) Turkish | [tk Türkmenler](/.github/README_TK.md) Turkmen | [uk Український](/.github/README_UK.md) Ukrainian | [ur اردو](/.github/README_UR.md) Urdu | [ug ئۇيغۇر](/.github/README_UG.md) Uyghur | [uz O'zbek](/.github/README_UZ.md) Uzbek | [vi Tiếng Việt](/.github/README_VI.md) Vietnamese | [cy Cymraeg](/.github/README_CY.md) Welsh | [xh isiXhosa](/.github/README_XH.md) Xhosa | [yi יידיש](/.github/README_YI.md) Yiddish | [yo Yoruba](/.github/README_YO.md) Yoruba | [zu Zulu](/.github/README_ZU.md) Zulu ) Available in 110 languages (108 when not counting English and North Korean, as North Korean has not been translated yet [Read about it here](/OldVersions/Korean(North)/README.md))

Translations in languages other than English are machine translated and are not yet accurate. No errors have been fixed yet as of March 21st 2021. Please report translation errors [here](https://github.com/seanpm2001/Computing-longevity/issues/). Make sure to backup your correction with sources and guide me, as I don't know languages other than English well (I plan on getting a translator eventually) please cite [wiktionary](https://en.wiktionary.org) and other sources in your report. Failing to do so will result in a rejection of the correction being published.

Note: due to limitations with GitHub's interpretation of markdown (and pretty much every other web-based interpretation of markdown) clicking these links will redirect you to a separate file on a separate page that isn't the intended page. You will be redirected to the [.github folder](/.github/) of this project, where the README translations are hosted.

Translations are currently done with Bing translate and DeepL. Support for Google Translate translations is coming to a close due to privacy concerns.

***

# Index

[00.0 - Top](#Top)

> [00.1 - Title](#The-<projectName>-project)

> [00.2 - Read this article in a different language](#Read-this-article-in-a-different-language)

> [00.3 - Index](#Index)

[01.0 - Description](#<projectName>)

[02.0 - About](#About)

[03.0 - History](#History)
  
> [03.1 - Pre-history](#Pre-history)

> [03.2 - Alpha History](#Alpha-history)

> [03.3 - Beta History](#Beta-history)

> [03.4 - Modern History](#Modern-history)

[04.0 - Wiki](#Wiki)

[05.0 - Non-compliant software](#Non-compliant-software)

[06.0 - Compliant software](#Compliant-software)

[07.0 - Non-compliant hardware](#Non-compliant-hardware)

[08.0 - Compliant hardware](#Compliant-hardware)

[09.0 - Copying](#Copying)

[10.0 - Credits](#Credits)

[11.0 - Authors](#Authors)

[12.0 - Installation](#Installation)

[13.0 - 404 page](#404-page)

[14.0 - Version history](#Version-history)

[15.0 - Software status](#Software-status)

[16.0 - Sponsor info](#Sponsor-info)

[17.0 - Contributers](#Contributers)

[18.0 - Issues](#Issues)

> [18.1 - Current issues](#Current-issues)

> [18.2 - Past issues](#Past-issues)

> [18.3 - Past pull requests](#Past-pull-requests)

> [18.4 - Active pull requests](#Active-pull-requests)

[19.0 - Resources](#Resources)

[20.0 - Contributing](#Contributing)

[21.0 - About README](#About-README)

[22.0 - README Version history](#README-version-history)

[23.0 - Technical notes](#Technical-notes)

[24.0 - Footer](#You-have-reached-the-end-of-the-README-file)

> [24.9 - End of file](#EOF)

***

# Computing-longevity
The website for the Computational Longevity Standardization project.

***

## About

See above. This project is for Computing longevity and longevity standards. Its current goals are to:

- [ ] End planned obsolescence in both software and hardware

- [ ] Catalog various hardware and software and its compliance with these standards.

The main goal is for computers to last at minimum 50 years, and software to work until an eternity after the end of time.

***
  
## History

This project has a short history so far.

### Pre-history

This project was published on 2021 August 20th at 5:08 pm in compliance with a new goal of software and hardware longevity compliance. It received a little bit of development before being abandoned for 14 days. Its foundation was laid, and a website was created. I experienced my first GitHub pages build fail here with the `INSTALL` file, this was later fixed in the 2021 Saturday 4th update.

### Alpha history

I finally got to updating this project on 2021 Saturday 4th, mainly fixing the website, and getting it ready and up to date. I also fixed the error by temporarily deleting 2 files. Once I figure out how to add the file back without conflict, I will.

### Beta history

No Beta history to show for this project.

### Modern history

No Modern history to show for this project.

***

## Wiki

[Click/tap here to view this projects Wiki](https://github.com/seanpm2001/Computing-longevity/wiki/)

If the project has been forked, the Wiki was likely removed. Luckily, I include an embedded version. You can view it [here](/External/ProjectWiki/).

***

## Non-compliant software

The following software is certified to be NOT compliant with any software longevity standards.

- Windows 95

- Windows 98

- Windows 2000

- Windows ME

- Windows NT 4

- Windows NT 5

- Windows XP

- Windows Vista

- Windows 7

- Windows 8

- Windows 8.1

- Windows 10

- Windows 11

(Reason for non-compliance: requires an Internet connection/serial number to install, cannot work at or after the year 10000)

- Microsoft Office (all versions prior to Microsoft Office 4.0)

(Reasons for non-compliance: requires an Internet connection/serial number to install, cannot work at or after the year 10000)


32 bit Linux

16 bit Linux

8 bit Linux

AmigaOS

AmigaOS 2

AmigaOS 3

AmigaOS 4

Ubuntu 4.10 (32 bit)

Ubuntu 5.04 (32 bit)

Ubuntu 5.10 (32 bit)

Ubuntu 6.06 (32 bit)

Ubuntu 6.10 (32 bit)

Ubuntu 7.04 (32 bit)

Ubuntu 7.10 (32 bit)

Ubuntu 8.04 (32 bit)

Ubuntu 8.10 (32 bit)

Ubuntu 9.04 (32 bit)

Ubuntu 9.10 (32 bit)

Ubuntu 10.04 (32 bit)

Ubuntu 10.10 (32 bit)

Ubuntu 11.04 (32 bit)

Ubuntu 11.10 (32 bit)

Ubuntu 12.04 (32 bit)

Ubuntu 12.10 (32 bit)

Ubuntu 13.04 (32 bit)

Ubuntu 13.10 (32 bit)

Ubuntu 14.04 (32 bit)

Ubuntu 14.10 (32 bit)

Ubuntu 15.04 (32 bit)

Ubuntu 15.10 (32 bit)

Ubuntu 16.04 (32 bit)

Ubuntu 16.10 (32 bit)

Ubuntu 17.04 (32 bit)

Ubuntu 17.10 (32 bit)

Ubuntu 18.04 (32 bit)

Ubuntu 18.10 (32 bit)

Ubuntu 19.04 (32 bit)

Ubuntu 19.10 (32 bit)

Ubuntu 20.04 (32 bit)

Ubuntu 20.10 (32 bit)

Ubuntu 21.04 (32 bit)

Fedora Core 1 (32 bit)

Fedora Core 2 (32 bit)

Fedora Core 3 (32 bit)

Fedora Core 4 (32 bit)

Fedora Core 5 (32 bit)

Fedora Core 6 (32 bit)

Fedora 7 (32 bit)

Fedora 8 (32 bit)

Fedora 9 (32 bit)

Fedora 10 (32 bit)

Fedora 11 (32 bit)

Fedora 12 (32 bit)

Fedora 13 (32 bit)

Fedora 14 (32 bit)

Fedora 15 (32 bit)

Fedora 16 (32 bit)

Fedora 17 (32 bit)

Fedora 18 (32 bit)

Fedora 19 (32 bit)

Fedora 20 (32 bit)

Fedora 21 (32 bit)

Fedora 22 (32 bit)

Fedora 23 (32 bit)

Fedora 24 (32 bit)

Fedora 25 (32 bit)

Fedora 26 (32 bit)

Fedora 27 (32 bit)

Fedora 28 (32 bit)

Fedora 29 (32 bit)

Fedora 30 (32 bit)

Fedora 31 (32 bit)

Fedora 32 (32 bit)

Fedora 33 (32 bit)

Fedora 34 (32 bit)

Fedora 35 (32 bit)

Fedora 36 (32 bit)

Minecraft (due to the require of online registration to install)

Windows XP mode (due to the requirement of online registration to install, and being 32 bit software)

Windows Server 2003 (online registration required)

Windows Server 2003 R2 (online registration required)

Windows Server 2008 (online registration required)

Windows Server 2008 R2 (online registration required)

Windows Server 2012 (online registration required)

Windows Server 2012 R2 (online registration required)

Windows Server 2016 (online registration required)

Windows Server 2016 R2 (online registration required)

Windows Server 2019 (online registration required)

Windows Server 2019 R2 (online registration required)

Red Hat Linux (all versions)

RHEL (pre-v6)

RHEL 7 (32 bit)

RHEL 8 (32 bit)

RHEL 9 (32 bit)

Debian Linux 1 (32 bit)

Debian Linux 2 (32 bit)

Debian Linux 3 (32 bit)

Debian Linux 4 (32 bit)

Debian Linux 5 (32 bit)

Debian Linux 6 (32 bit)

Debian Linux 7 (32 bit)

Debian Linux 8 (32 bit)

Debian Linux 9 (32 bit)

Debian Linux 10 (32 bit)

Debian Linux 11 (32 bit)

Debian Linux 12 (32 bit)

K Desktop Environment 1.x (32 bit)

K Desktop Environment 2.x (32 bit)

K Desktop Environment 3.x (32 bit)

KDE Plasma 4 (32 bit)

KDE Plasma 5 (32 bit)

GNOME 1 (32 bit)

GNOME 2 (32 bit)

GNOME 3 (32 bit)

GNOME 40 (32 bit)

GNOME 41 (32 bit)

Adobe Photoshop (all versions) (requires online registration)

Adobe Flash (all versions) (requires online registration)

Adobe Animate (all versions) (requires online registration)

Adobe InDesign (all versions) (requires online registration)

Adobe Bridge (all versions) (requires online registration)

Adobe Muse (all versions) (requires online registration)

Adobe Premiere Pro (all versions) (requires online registration)

Adobe After effects (all versions) (requires online registration)

Adobe Dreamweaver (all versions) (requires online registration)

Adobe Creative cloud (all versions) (requires online registration)

Adobe  (all versions) (requires online registration)

Java (32 bit)

JavaScript (32 bit)

Python (32 bit)

Ruby (32 bit)

SQL (32 bit and 16 bit)

Perl (32 bit)

MATLAB (32 bit)

Go (32 bit)

Go! (32 bit)

Haskell (32 bit)

Elixir (32 bit)

Eiffel (32 bit)

Erlang (32 bit)

ECMAScript (32 bit)

FORTRAN (8 bit, 16 bit, 32 bit)

D (32 bit)

Dart (32 bit)

Caml (32 bit)

C (32 bit)

C++ (32 bit)

C# (32 bit)

PowerShell (32 bit)

Swift (32 bit)

Boo (32 bit)

BASIC (8 bit, 16 bit)

AppleScript (32 bit)

Objective-C (8 bit, 16 bit, 32 bit)

Objective-C++ (16 bit, 32 bit)

ActionScript (16 bit, 32 bit)

AngelScript (32 bit)

Forth (16 bit, 32 bit)

F# (32 bit)

Genie (32 bit)

GLSL (32 bit)

HLSL (32 bit)

Google Apps Script (32 bit)

Inno Setup (32 bit)

Idris (32 bit)

Kotlin (32 bit)

Lua (32 bit)

Lisp (8 bit, 16 bit, 32 bit)

Makefile (16 bit, 32 bit)

M4 (16 bit, 32 bit)

Pascal (16 bit, 32 bit)

Pig (32 bit)

PostScript (32 bit)

PureScript (32 bit)

QML (32 bit)

Q# (32 bit)

R (32 Bit)

REBOL (32 bit)

Raku (32 bit)

Rust (32 bit)

Scheme (8 bit, 16 bit, 32 bit)

Scala (32 bit)

Sass (32 bit)

TypeScript (32 bit)

TCL (32 bit)

TOML (32 bit)

UnrealScript (32 bit)

Vala (32 bit)

Visual Basic Script (8 bit, 16 bit, 32 bit)

VB.NET (32 bit)

BrightScript (32 bit)

XSLT (32 bit)

Yacc (32 bit)

YAML (32 bit)

WebAssembly (32 bit)

Liquid (32 bit)

ZenScript (32 bit)

## Compliant software

The following software is certified to be compliant with software longevity standards.

Ubuntu 9.04 (64 bit)

Ubuntu 9.10 (64 bit)

Ubuntu 10.04 (64 bit)

Ubuntu 10.10 (64 bit)

Ubuntu 11.04 (64 bit)

Ubuntu 11.10 (64 bit)

Ubuntu 12.04 (64 bit)

Ubuntu 12.10 (64 bit)

Ubuntu 13.04 (64 bit)

Ubuntu 13.10 (64 bit)

Ubuntu 14.04 (64 bit)

Ubuntu 14.10 (64 bit)

Ubuntu 15.04 (64 bit)

Ubuntu 15.10 (64 bit)

Ubuntu 16.04 (64 bit)

Ubuntu 16.10 (64 bit)

Ubuntu 17.04 (64 bit)

Ubuntu 17.10 (64 bit)

Ubuntu 18.04 (64 bit)

Ubuntu 18.10 (64 bit)

Ubuntu 19.04 (64 bit)

Ubuntu 19.10 (64 bit)

Ubuntu 20.04 (64 bit)

Ubuntu 20.10 (64 bit)

Ubuntu 21.04 (64 bit)

VLC Media Player (all versions)

QuickTime Player (all versions)

Windows Media Player (all versions)

Windows Movie Maker (all versions)

Windows calculator (all versions)

Mari0 (all versions)

GNOME System Monitor (all versions)

Windows Task Manager (all versions)

Vim Text Editor (all versions)

GIMP (all versions)

Microsoft Paint (all versions)

Blender (all versions)

Windows Notepad (all versions)

Notepad++ (all versions)

Microsoft Minesweeper (all versions)

Microsoft Solitaire (all versions)

GNOME Solitaire (all versions)

GNOME Mines (all versions)

Okular (all versions)

GNOME Image viewer (all versions)

GNOME Cheese (only on 64 bit systems)

GNOME Transmission (only on 64 bit systems)

LibreOffice (only on 64 bit systems)

LibreOffice Writer (only on 64 bit systems)

LibreOffice Calc (only on 64 bit systems)

LibreOffice Draw (only on 64 bit systems)

LibreOffice Impress (only on 64 bit systems)

GNOME AisleRot Solitaire (only on 64 bit systems)

Fedora 7 (64 bit)

Fedora 8 (64 bit)

Fedora 9 (64 bit)

Fedora 10 (64 bit)

Fedora 11 (64 bit)

Fedora 12 (64 bit)

Fedora 13 (64 bit)

Fedora 14 (64 bit)

Fedora 15 (64 bit)

Fedora 16 (64 bit)

Fedora 17 (64 bit)

Fedora 18 (64 bit)

Fedora 19 (64 bit)

Fedora 20 (64 bit)

Fedora 21 (64 bit)

Fedora 22 (64 bit)

Fedora 23 (64 bit)

Fedora 24 (64 bit)

Fedora 25 (64 bit)

Fedora 26 (64 bit)

Fedora 27 (64 bit)

Fedora 28 (64 bit)

Fedora 29 (64 bit)

Fedora 30 (64 bit)

Fedora 31 (64 bit)

Fedora 32 (64 bit)

Fedora 33 (64 bit)

Fedora 34 (64 bit)

Fedora 35 (64 bit)

Fedora 36 (64 bit)

Oracle VM VirtualBox (only on 64 bit systems)

Windows Character map (all versions)

Windows Registry (all versions)

Hyper-V (64 bit)

RHEL 7 (64 bit)

RHEL 8 (64 bit)

RHEL 9 (64 bit)

Debian Linux 6 (64 bit)

Debian Linux 7 (64 bit)

Debian Linux 8 (64 bit)

Debian Linux 9 (64 bit)

Debian Linux 10 (64 bit)

Debian Linux 11 (64 bit)

Debian Linux 12 (64 bit)

KDE Plasma 4 (64 bit)

KDE Plasma 5 (64 bit)

GNOME 3 (64 bit)

GNOME 40 (64 bit)

GNOME 41 (64 bit)

Snowcraft (flash game)

GNOME Screenshot (only on 64 bit versions)

GNOME Calendar (64 bit)

XEYES

XCALC

XCLOCK

Java (64 bit)

JavaScript (64 bit)

Python (64 bit)

Ruby (64 bit)

SQL (64 bit)

Perl (64 bit)

MATLAB (64 bit)

Go (64 bit)

Go! (64 bit)

Haskell (64 bit)

Elixir (64 bit)

Eiffel (64 bit)

Erlang (64 bit)

ECMAScript (64 bit)

FORTRAN (64 bit)

D (64 bit)

Dart (64 bit)

Caml (64 bit)

C (64 bit)

C++ (64 bit)

C# (64 bit)

PowerShell (64 bit)

Swift (64 bit)

Boo (64 bit)

AppleScript (64 bit)

Objective-C (64 bit)

Objective-C++ (64 bit)

ActionScript (64 bit)

AngelScript (64 bit)

Forth (64 bit)

F# (64 bit)

Genie (64 bit)

GLSL (64 bit)

HLSL (64 bit)

Google Apps Script (64 bit)

Inno Setup (64 bit)

Idris (64 bit)

Kotlin (64 bit)

Lua (64 bit)

Lisp (64 bit)

Makefile (64 bit)

M4 (64 bit)

Pascal (64 bit)

Pig (64 bit)

PostScript (64 bit)

PureScript (64 bit)

QML (64 bit)

Q# (64 bit)

R (64 Bit)

REBOL (64 bit)

Raku (64 bit)

Rust (64 bit)

Scheme (64 bit)

Scala (64 bit)

Sass (64 bit)

TypeScript (64 bit)

TCL (64 bit)

TOML (64 bit)

UnrealScript (64 bit)

Vala (64 bit)

Visual Basic Script (64 bit)

VB.NET (64 bit)

BrightScript (64 bit)

XSLT (64 bit)

Yacc (64 bit)

YAML (64 bit)

WebAssembly (64 bit)

Liquid (64 bit)

ZenScript (64 bit)

## Non-compliant hardware

The following hardware is certified to be NOT compliant with any hardware longevity standards

- Chromebooks (all models)

- ChromeBlets (all models)

- ChromeBits (all models)

- ChromeBases (all models)

(Reason for non-compliance: requires an Internet connection to use, support ends within a decade of purchase)

## Compliant hardware

The following hardware is certified to be compliant with hardware longevity standards

- [x] Commodore 64

- [x] Nintendo Entertainment System

- [x] Commodore 128

- [x] VIC-20

In progress with compliance:

- [ ] PlayStation 1

- [ ] PlayStation 2

- [ ] Nintendo DSi

- [ ] Nintendo 2DS

- [ ] Nintendo Wii

- [ ] DWAVE 2000 (Quantum Computer)

- [ ] Super Nintendo Entertainment System

***

## Copying

View the copying license for this project [here](/COPYING) (if you haven't built the project yet with the makefile, here is the original link: [COPYINGL](/COPYINGL)

Please note that you also have to follow the rules of the GNU General Public License v3 (GPL3) which you can view [here](/LICENSE.txt)

***

## Credits

View the credits file for this project and see the people who got together to make this project by [clicking/tapping here](/CREDITS)

***

## Authors

View the authors file for this project and see the authors of this project by [clicking/tapping here](/AUTHORS)

***

## Installation

View the installation instructions file for this project [here](/INSTALL)

Requirements: Jekyll, GitHub emulator (may not exist yet)

***

## 404 page

Test the 404 page for this project by [clicking/tapping here](/Site/404/THIS-WILL-NEVER-WORK/ABJAB/DXV48/22846/FILE.xabcdfgxlma329)

Getting a different 404 page? View the 404 page directly by [clicking/tapping here](/404.htm;)

***

## Sponsor info

![SponsorButton.png](/SponsorButton.png)

You can sponsor this project if you like, but please specify what you want to donate to. [See the funds you can donate to here](https://github.com/seanpm2001/Sponsor-info/tree/main/For-sponsors/)

You can view other sponsor info [here](https://github.com/seanpm2001/Sponsor-info/)

Try it out! The sponsor button is right up next to the watch/unwatch button.

***

## Version history

**Version history currently unavailable**

**No other versions listed**

***

## Software status

All of my works are free some restrictions. DRM (**D**igital **R**estrictions **M**anagement) is not present in any of my works.

![DRM-free_label.en.svg](/DRM-free_label.en.svg)

This sticker is supported by the Free Software Foundation. I never intend to include DRM in my works.

I am ussing the abbreviation "Digital Restrictions Management" instead of the more known "Digital Rights Management" as the common way of addressing it is false, there are no rights with DRM. The spelling "Digital Restrictions Management" is more accurate, and is supported by [Richard M. Stallman (RMS)](https://en.wikipedia.org/wiki/Richard_Stallman/) and the [Free Software Foundation (FSF)](https://en.wikipedia.org/wiki/Free_Software_Foundation/)

This section is used to raise awareness for the problems with DRM, and also to protest it. DRM is defective by design and is a major threat to all computer users and software freedom.

Image credit: [defectivebydesign.org/drm-free/...](https://www.defectivebydesign.org/drm-free/how-to-use-label/)

***

## Contributers

Currently, I am the only contributer. Contributing is allowed, as long as you follow the rules of the [CONTRIBUTING.md](/CONTRIBUTING.md) file.

> * 1. [seanpm2001](https://github.com/seanpm2001/) - 25 commits (As of Saturday, 2021 September 4th at 07:02 pm)

> * 2. No other contributers.

***

## Issues

### Current issues

* None at the moment

* No other current issues

If the repository has been forked, issues likely have been removed. Luckily I keep an archive of certain images [here](/.github/Issues/)

[Read the privacy policy on issue archival here](/.github/Issues/README.md)

**TL;DR**

I archive my own issues. Your issue won't be archived unless you request it to be archived.

### Past issues

* None at the moment

* No other past issues

If the repository has been forked, issues likely have been removed. Luckily I keep an archive of certain images [here](/.github/Issues/)

[Read the privacy policy on issue archival here](/.github/Issues/README.md)

**TL;DR**

I archive my own issues. Your issue won't be archived unless you request it to be archived.

### Past pull requests

* None at the moment

* No other past pull requests

If the repository has been forked, issues likely have been removed. Luckily I keep an archive of certain images [here](/.github/Issues/)

[Read the privacy policy on issue archival here](/.github/Issues/README.md)

**TL;DR**

I archive my own issues. Your issue won't be archived unless you request it to be archived.

### Active pull requests

* None at the moment

* No other active pull requests

If the repository has been forked, issues likely have been removed. Luckily I keep an archive of certain images [here](/.github/Issues/)

[Read the privacy policy on issue archival here](/.github/Issues/README.md)

**TL;DR**

I archive my own issues. Your issue won't be archived unless you request it to be archived.

***

## Resources

Here are some other resources for this project:

[Project language file A](/PROJECT_LANG_1.htm)

[Join the discussion on GitHub](https://github.com/seanpm2001/Computing-longevity/discussions/)

No other resources at the moment.

***

## Contributing

Contributing is allowed for this project, as long as you follow the rules of the `CONTRIBUTING.md` file.

[Click/tap here to view the contributing rules for this project](/CONTRIBUTING.md)

***

## About README

**File type:** `Markdown (*.md *.mkd *.markdown)`

**File version:** `2 (2021 Monday September 6th at 3:31 pm)`

**Line count:** `1,337`

**Language:** `English (US)`

***

## README version history

Version 0.1 (Sunday, March 21st 2021 at 7:50 pm)

> Changes:

> * Started the file

> * Added the title section

> * Added the index

> * Added the about section

> * Added the Wiki section

> * Added the version history section

> * Added the issues section.

> * Added the past issues section

> * Added the past pull requests section

> * Added the active pull requests section

> * Added the contributors section

> * Added the contributing section

> * Added the about README section

> * Added the README version history section

> * Added the resources section

> * Added a software status section, with a DRM free sticker and message

> * Added the sponsor info section

> * No other changes in version 0.1

Version 0.11 (Friday, July 16th 2021 at 9:20 pm)

> Changes:

> * Updated several sections with corrected template syntax

> * Added the history section

> * Updated the language list switcher section

> * Updated the file info section

> * Updated the file history section

> * No other changes in version 0.11

Version 0.11B (Friday, July 16th 2021 at 9:25 pm)

> Changes:
  
> * Fixed the footer, removed bad link (ddg.com does not redirect to duckduckgo)
  
> * Updated the file info section

> * Updated the file history section

> * No other changes in version 0.11B

Version 0.12A (Thursday, July 22nd 2021 at 6:26 pm)

> Changes:
  
> * The typo `SNU Erotica` was removed entirely

> * Added a better name than file.svg

> * Fixed the title section
  
> * Fixed the index
  
> > * Added the history section

> * Minor formatting fixes

> * Updated the file info section

> * Updated the file history section

> * No other changes in version 0.11B

Version 1 (2021 Saturday September 4th at 7:02 pm)

> Changes:

> * Updated tag data

> * Added compliant, and noncompliant software and hardware lists

> * Updated the index

> * Updated the file info section

> * Updated the file history section

> * Times are now compliant with ISO:8601 and use YYYY-MM-DD rather than MM-DD-YYYY

> * Updated the index

> * Added the authors section

> * Updated the footer, adding support for the Swisscows search engine as a 4th option

> * Added the copying section

> * Added the credits section

> * Added the installation section

> * Added the 404 page test section

> * Updated the resources section

> * Updated the contributors section

> * Added the technical notes section

> * No other changes in version 1

Version 2 (Monday, 2021 September 6th at 3:31 pm)

> Changes:

> * Content update: added over 100 entries for compliant and non-compliant software

> * Updated the file info section

> * Updated the file history section

> * No other changes in version 2Con

Version 3 (Coming soon)

> Changes:

> * Coming soon

> * No other changes in version 3

Version 4 (Coming soon)

> Changes:

> * Coming soon

> * No other changes in version 4

***

## You have reached the end of the README file

( [Back to top](#Top) | [Exit to GitHub](https://github.com) | [Exit to Bing](https://www.bing.com/) | [Exit to DuckDuckGo](https://duckduckgo.com) | [Exit to Ecosia](https://www.ecosia.com/) | [Exit to Swisscows](https://www.swisscows.com/) )

### EOF

***
