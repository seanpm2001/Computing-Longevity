
***

# Development branch is deprecated

Pull requests are just too difficult to do constantly at the moment due to `these 2 branches have entirely different histories` so I can't keep merging. The development branch is in the process of deprecation

[/https://github.com/seanpm2001/Template_GitHubPages_Default_V4/blob/Development/DEVELOPMENT-BRANCH/)

This is the development branch. Changes are made here en masse before they are officially launched to the site via a pull request.

***
