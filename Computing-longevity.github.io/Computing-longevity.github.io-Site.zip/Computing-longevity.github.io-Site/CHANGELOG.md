
***

# Changelog

## V1 of Template_GitHubPages

> Changes:

* To be added here

* No other changes in V1

## V2 of Template_GitHubPages

> Changes:

* To be added here

* No other changes in V2

## V3 of Template_GitHubPages

> Changes:

* To be added here

* No other changes in V3

## V4 of Template_GitHubPages_Default

> Changes:

* To be added here

* No other changes in V4

## V5 of Template_GitHubPages_Default

> Changes:

* Typo: `SNU Erotica` removed entirely

* Added better alt names than file.svg

* Commented out the first line of the By: section

* Fixed the index, and added the history section

* Added the changelog

* No other changes in V5

***

