
***

# Privacy policy

I archive my own GitHub discussions and issues. By default, I respect users privacy, and will not have your issue or discussion archived. You have to specifically ask for it to be archived if you want it to be.

***
